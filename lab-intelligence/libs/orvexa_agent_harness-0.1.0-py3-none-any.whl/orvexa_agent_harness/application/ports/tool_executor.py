from typing import Protocol

from ..contracts import ToolResult, ToolCall

class ToolExecutor(Protocol):
    async def execute(self, call: ToolCall) -> ToolResult:
        """Execute a tool call and return the result."""
        ...