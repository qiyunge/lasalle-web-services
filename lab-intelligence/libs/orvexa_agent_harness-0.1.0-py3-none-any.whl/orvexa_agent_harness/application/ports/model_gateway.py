from typing import Protocol

from orvexa_agent_harness.application.contracts import Context
from orvexa_agent_harness.application.contracts import ModelResponse


class ModelGateway(Protocol):
    """
    A protocol that defines the interface for a model gateway.

    This protocol specifies the methods that any class implementing it must provide.
    It serves as a contract for interacting with a model gateway, allowing for
    different implementations to be used interchangeably.

    Methods:
        send_message: Sends a message to the model and returns the response.
        get_model_info: Retrieves information about the model.
    """

    async def sample(self, context:Context) -> ModelResponse:
        """
        Sends a message to the model and returns the response.

        Args:
            context: The context of the conversation.
        Returns:
            The response from the model.
        """
        pass

        