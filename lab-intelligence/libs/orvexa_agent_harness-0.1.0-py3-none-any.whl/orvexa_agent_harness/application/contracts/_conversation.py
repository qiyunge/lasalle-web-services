from dataclasses import dataclass

from typing import TypeAlias

from ._tool import ToolResult
from ._model import FinalAnswer, ToolCalls

@dataclass(frozen=True)
class Message:
    """
    Represents a message in a conversation.

    Attributes:
        content: The content of the message.
    """
    content: str

@dataclass(frozen=True)
class UserMessage(Message):
    """
    Represents a message from the user.

    Attributes:
        content: The content of the user's message.
    """
    pass

@dataclass(frozen=True)
class AssistantMessage(Message):
    """
    Represents a message from the assistant.

    Attributes:
        content: The content of the assistant's message.
    """
    pass