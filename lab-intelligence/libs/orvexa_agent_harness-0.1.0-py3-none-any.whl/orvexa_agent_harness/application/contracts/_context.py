from abc import ABC

from dataclasses import dataclass

from orvexa_agent_harness.application.contracts._tool import ToolResult

from ._conversation import Message
from ._model import ToolCall

class ContextItem(ABC):
    """
    Abstract base class for context items.
    """
    pass

@dataclass(frozen=True)
class Context:
    """
    Represents the context of a conversation.

    Attributes:
        items: A list of context items.
    """
    items: tuple[ContextItem, ...]

@dataclass(frozen=True)
class InstructionContextItem(ContextItem):
    """
    Represents an instruction context item.

    Attributes:
        instruction: The instruction content.
    """
    content: str

@dataclass(frozen=True)
class ConversationContextItem(ContextItem):
    """
    Represents a conversation context item.

    Attributes:
        messages: A list of conversation messages.
    """
    message:Message

@dataclass(frozen=True)
class ToolCallItem(ContextItem):
    """
    Represents a tool call context item.

    Attributes:
        tool_name: The name of the tool.
        tool_input: The input provided to the tool.
    """
    call: ToolCall

@dataclass(frozen=True)
class ToolResultItem(ContextItem):
    """
    Represents a tool result context item.

    Attributes:
        tool_name: The name of the tool.
        tool_output: The output returned by the tool.
    """
    result: ToolResult