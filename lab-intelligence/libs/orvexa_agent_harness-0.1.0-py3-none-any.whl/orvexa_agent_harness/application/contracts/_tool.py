from dataclasses import dataclass

@dataclass(frozen=True)
class ToolCall:
    """
    Represents a tool invocation requested by the model.

    Attributes:
        id: Identifies the tool call and correlates its result.
        name: The name of the tool being called.
        args: The arguments to pass to the tool.
    """
    id: str
    name: str
    args: dict[str,object]

@dataclass(frozen=True)
class ToolResult:
    """
    Represents the result of a tool invocation.

    Attributes:
        call_id: Identifies the tool call that produced this result.
        result: The result of the tool invocation.
    """
    call_id: str
    content: str
