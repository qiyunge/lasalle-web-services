from dataclasses import dataclass
from typing import TypeAlias

from ._tool import ToolCall

@dataclass(frozen=True)
class ToolCalls:
    """
    Represents a collection of tool invocations requested by the model.

    Attributes:
        calls: A list of tool calls.
    """
    calls: tuple[ToolCall, ...]  # Using a tuple to represent an immutable collection of ToolCall objects   

@dataclass(frozen=True)
class FinalAnswer:
    """
    Represents the final answer provided by the model.

    Attributes:
        content: The final answer content.
    """
    content: str

ModelResponse: TypeAlias = ToolCalls | FinalAnswer